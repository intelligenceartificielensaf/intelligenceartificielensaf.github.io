# multiAgents.py
# -*- coding: utf-8 -*-
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):
    """
      Classe d'un agent de Reflèxe qui choisit son action pour chaque
      choix en examinant ses alternatives par une fonction d'évaluation.

      Ce code vous est fourni comme guide, Dans vous pouvez le changer
      sans ruiner au protopyes des méthodes
    """


    def getAction(self, gameState):
        """
        Vous n'avez pas besoin de modifier cette fonction, mais si vous  penser
        pouvoir l'améliorer vous le bienvenue.

        getAction choisit la meilleure action selon la fonction d'évaluation.

        Comme pour le premier projet, getAction prend un etat GameState et
        renvoie une Directions.X ou X est dans {North, South, West, East, Stop}
        """
        # Obtenier les coups légaux  
        legalMoves = gameState.getLegalActions()

        # Choisir la meilleure options
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Ajouter d'autre caractéristique si vous voulez"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Implementer une meilleure fonction ici


        La fonction d'évalation prend comme argument l'état courant
        currentGameState et l'action choisie et renvoie un nombre indiquant la
        préférence de l'agent. Plus le  nombre est elevé plus pacman a des
        changes pour gagner


        Le code suivant extrait pour vous les informations utiles du jeu,comme
        la nouvelle position de pacman après l'action, la nouriture, les
        fantomes, et le temps en peur des fantomes.

        Afficher ces variables pour voir leur informations et combiner les pour
        améliorer le comportement de Pacman.
        """
        # Information utiles de la classe GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"
        return successorGameState.getScore()

def scoreEvaluationFunction(currentGameState):
    """
      This default evaluation function just returns the score of the state.
      The score is the same one displayed in the Pacman GUI.

      This evaluation function is meant for use with adversarial search agents
      (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
      This class provides some common elements to all of your
      multi-agent searchers.  Any methods defined here will be available
      to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

      You *do not* need to make any changes here, but you can if you want to
      add functionality to all your adversarial search agents.  Please do not
      remove anything, however.

      Note: this is an abstract class: one that should not be instantiated.  It's
      only partially specified, and designed to be extended.  Agent (game.py)
      is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
      Votre agent minimax (question 2)
    """

    def getAction(self, gameState):
        """
          Renvoie l'action de minimax à partir de l'état courant
          gameState en utilisant une profondeur : self.depth
          et la fonction d'évaluation : self.evaluationFunction

          Voici quelque appels qui peuvent vous être utiles

          gameState.getLegalActions(agentIndex):
            Renvoie une liste d'action légales pour l'agent indexé
            par agentIndex. 
            agentIndex = 0 =====> Pacman
            agentIndex >=1 ======> fantômes

          gameState.generateSuccessor(agentIndex, action):
            Renvoie les successeurs de l'état après j'exécution
            d'une action

          gameState.getNumAgents():
            Renvoie le nombre d'agent dans le jeu
        """
        "*** YOUR CODE HERE ***"
        util.raiseNotDefined()

class AlphaBetaAgent(MultiAgentSearchAgent):
    """
       Votre agent minimax avec élagage alpha-beta
       (question 3)
    """

    def getAction(self, gameState):
        """
          Renvoie l'action minimax en utilisant une profendeur
          self.depth and la fonction d'évaluation
          self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"
        util.raiseNotDefined()

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Votre agent ExpectiMax (question 4)
    """

    def getAction(self, gameState):
        """
          Renvoie l'action selon expectimax 

          On considère que tous les fantômes choisissent une action au
          hasard parmi leurs actions possiblesj
        """
        "*** YOUR CODE HERE ***"
        util.raiseNotDefined()

def betterEvaluationFunction(currentGameState):
    """
      Votre fonction extreme qui peut considérer:
      * Chasse des fantômes
      * Prendre toute la nouriture
      * Pellule de puissance
      (Question 5)

      DESCRIPTION:  <Ecrire une description de votre fonctionr
    """
    "*** YOUR CODE HERE ***"
    util.raiseNotDefined()

# Abbreviation
better = betterEvaluationFunction

